#!/usr/bin/env python3
"""Offline research scaffold. Python 3.9+, standard library, no network or LLM.

Adapter seams are marked ADAPTER. The fixture data and URLs are fictional.
"""
import argparse
import datetime as dt
import hashlib
import json
import re
import sqlite3
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STOP = set("a an the is are was were do does did can could should would will "
           "what which who how much tell me about please at on in to of for "
           "and or with it its we our you your i have has available currently "
           "today now signaldesk product support supports supported integrate "
           "integrates integration integrations connect connects connector "
           "plan plans monthly month per cost costs pricing price".split())
ALIASES = {
    "pricing": {"pricing", "price", "cost", "costs", "monthly", "subscription"},
}


def tokens(text):
    """Small lexical normalizer, deliberately not semantic understanding."""
    raw = set(re.findall(r"[a-z0-9]+", text.lower()))
    meaningful = raw - STOP
    for canonical, terms in ALIASES.items():
        if raw & terms:
            meaningful.add(canonical)
    return meaningful


def load_documents(path):
    docs = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {"id", "title", "text", "source_url", "published_at", "verified_at",
                "valid_from", "valid_to", "allowed_principals", "keywords"}
    ids = set()
    for doc in docs:
        missing = required - doc.keys()
        if missing:
            raise ValueError("Document missing fields: " + ", ".join(sorted(missing)))
        if doc["id"] in ids:
            raise ValueError("Duplicate document ID")
        ids.add(doc["id"])
        for field in ("published_at", "verified_at", "valid_from", "valid_to"):
            if doc[field] is not None:
                dt.date.fromisoformat(doc[field])
        doc["content_hash"] = hashlib.sha256(doc["text"].encode()).hexdigest()
    return docs


def authorize_and_filter(docs, principal, as_of, max_age_days):
    """Trusted code filters before the model/retriever could see content.

    ADAPTER: derive principal from authenticated server identity, not CLI input.
    ADAPTER: ingest verified timestamps and live permissions from your sources.
    """
    day = dt.date.fromisoformat(as_of)
    eligible = []
    for doc in docs:
        allowed = doc["allowed_principals"]
        if "public" not in allowed and principal not in allowed:
            continue
        start = dt.date.fromisoformat(doc["valid_from"])
        end = dt.date.fromisoformat(doc["valid_to"]) if doc["valid_to"] else None
        verified = dt.date.fromisoformat(doc["verified_at"])
        # This demo only returns evidence known by the requested date.
        if start > day or (end is not None and day > end) or verified > day:
            continue
        if (day - verified).days > max_age_days:
            continue
        eligible.append(doc)
    return eligible


def retrieve(query, docs, principal, as_of, max_age_days, top_k=3):
    """ADAPTER: replace lexical matching with hybrid search + reranking.

    Keep permission/freshness constraints upstream. All informative query
    tokens must occur in a candidate, so related evidence is not mislabeled
    as support for an unknown detail. This intentionally favors abstention.
    """
    terms = tokens(query)
    if not terms:
        return []
    eligible = authorize_and_filter(docs, principal, as_of, max_age_days)
    hits = []
    for doc in eligible:
        doc_terms = tokens(doc["title"] + " " + doc["text"] + " " +
                           " ".join(doc["keywords"]))
        if not terms.issubset(doc_terms):
            continue
        # Transparent toy score; this is not BM25 or an embedding similarity.
        score = len(terms) / max(len(doc_terms), 1)
        hits.append((score, doc["verified_at"], doc))
    hits.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [item[2] for item in hits[:top_k]]


def compose(query, evidence):
    """ADAPTER: add model synthesis here, then validate every claim/source ID.

    The offline version quotes matching fixture facts without inference.
    It does not answer arbitrary natural-language questions.
    """
    findings = []
    for doc in evidence:
        findings.append({
            "claim": doc["text"],
            "evidence_status": "supported_by_fixture",
            "source_id": doc["id"],
            "citation": {
                "title": doc["title"], "url": doc["source_url"],
                "published_at": doc["published_at"],
                "verified_at": doc["verified_at"],
                "content_hash": doc["content_hash"],
                "fixture": True,
            },
        })
    gaps = [] if findings else [{
        "question": query,
        "reason": "No sufficiently matching, current, authorized evidence was found.",
        "next_step": "Narrow the question or add a verified source. Absence of a match does not prove absence of a capability.",
    }]
    return {"findings": findings, "gaps": gaps}


def open_db(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.execute("CREATE TABLE IF NOT EXISTS runs ("
                 "run_id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, state_json TEXT NOT NULL)")
    conn.commit()
    return conn


def save_state(conn, state):
    conn.execute("INSERT INTO runs VALUES (?, ?, ?) ON CONFLICT(run_id) DO UPDATE SET "
                 "updated_at=excluded.updated_at, state_json=excluded.state_json",
                 (state["run_id"], dt.datetime.now(dt.timezone.utc).isoformat(),
                  json.dumps(state, ensure_ascii=False)))
    conn.commit()


def new_state(query, principal, as_of, max_age_days, max_steps):
    return {"run_id": uuid.uuid4().hex[:12], "query": query,
            "principal": principal, "as_of": as_of, "max_age_days": max_age_days,
            "max_steps": max_steps, "steps_used": 0, "status": "running",
            "completed": [], "evidence": [], "result": None}


def run_pipeline(state, docs, conn):
    save_state(conn, state)
    for step in ("retrieve", "compose"):
        if step in state["completed"]:
            continue
        if state["steps_used"] >= state["max_steps"]:
            state["status"] = "budget_exhausted"
            save_state(conn, state)
            return report(state)
        # Charge before execution; checkpoint after each completed action.
        state["steps_used"] += 1
        save_state(conn, state)
        if step == "retrieve":
            state["evidence"] = retrieve(state["query"], docs, state["principal"],
                                         state["as_of"], state["max_age_days"])
        else:
            # Recheck current source permissions and freshness on resume.
            permitted = {d["id"]: d for d in authorize_and_filter(
                docs, state["principal"], state["as_of"], state["max_age_days"])}
            state["evidence"] = [permitted[d["id"]] for d in state["evidence"]
                                 if d["id"] in permitted and
                                 permitted[d["id"]]["content_hash"] == d["content_hash"]]
            state["result"] = compose(state["query"], state["evidence"])
        state["completed"].append(step)
        save_state(conn, state)
    state["status"] = "complete" if state["result"]["findings"] else "evidence_gap"
    save_state(conn, state)
    return report(state)


def report(state):
    result = state["result"] or {"findings": [], "gaps": [{
        "question": state["query"],
        "reason": "Step budget exhausted before a report was composed.",
        "next_step": "Resume this run with a larger --max-steps value.",
    }]}
    return {"run_id": state["run_id"], "mode": "offline_fixture_scaffold",
            "query": state["query"], "as_of": state["as_of"],
            "status": state["status"], "steps_used": state["steps_used"],
            "completed_steps": state["completed"], **result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", help="Question to retrieve evidence for")
    parser.add_argument("--docs", default=str(ROOT / "sample_docs.json"))
    parser.add_argument("--db", default=str(ROOT / "runs.sqlite3"))
    parser.add_argument("--as-of", default="2026-11-16", help="Fixture date YYYY-MM-DD")
    parser.add_argument("--max-age-days", type=int, default=45)
    parser.add_argument("--principal", default="public", choices=["public", "internal"],
                        help="Fixture identity only; this is NOT authentication")
    parser.add_argument("--max-steps", type=int, default=2)
    parser.add_argument("--resume-run", help="Resume a stored run; preserves its query and scope")
    args = parser.parse_args()
    if args.max_steps < 1 or args.max_age_days < 0:
        parser.error("--max-steps must be positive; --max-age-days cannot be negative")
    try:
        dt.date.fromisoformat(args.as_of)
        docs = load_documents(args.docs)
        conn = open_db(args.db)
        if args.resume_run:
            row = conn.execute("SELECT state_json FROM runs WHERE run_id=?",
                               (args.resume_run,)).fetchone()
            if not row:
                parser.error("No saved run with that ID in the selected database")
            state = json.loads(row[0])
            state["max_steps"] = args.max_steps
            state["status"] = "running"
            # A completed run is replayed only after rechecking retrieval scope.
            # Reuse checkpoints only for incomplete runs in this teaching scaffold.
            if "compose" in state["completed"]:
                parser.error("Run already finished; use --query for a fresh permission-checked run")
        else:
            if not args.query or not args.query.strip():
                parser.error("Provide --query or --resume-run")
            state = new_state(args.query.strip(), args.principal, args.as_of,
                              args.max_age_days, args.max_steps)
        result = run_pipeline(state, docs, conn)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        conn.close()
    except (ValueError, OSError, sqlite3.Error) as exc:
        parser.exit(1, "Error: " + str(exc) + "\n")


if __name__ == "__main__":
    main()
