#!/usr/bin/env python3
"""Optional real model → MCP → HTTP loop. Paid model calls require credentials."""
import argparse
import asyncio
import json
import os
from mcp import Client
from mcp_client import server_parameters
from live_agent import SYSTEM, validate_final


async def run_mcp_agent(model_client, mcp_client, query, model, max_turns=6, max_tools=6):
    discovered = await mcp_client.list_tools()
    # Discovery is not permission. Expose only the host's approved tool name.
    tools = [{"name": t.name, "description": t.description, "input_schema": t.input_schema}
             for t in discovered.tools if t.name == "retrieve_knowledge"]
    if not tools:
        raise ValueError("Approved retrieve_knowledge tool was not discovered")
    messages, evidence, trace = [{"role": "user", "content": query}], {}, []
    calls_used = 0
    usage = {"input_tokens": 0, "output_tokens": 0}
    for turn in range(max_turns):
        response = await asyncio.to_thread(model_client.messages.create,
            model=model, max_tokens=1200, system=SYSTEM, tools=tools, messages=messages,
            tool_choice={"type": "tool", "name": "retrieve_knowledge"} if turn == 0 else {"type": "auto"})
        usage["input_tokens"] += response.usage.input_tokens
        usage["output_tokens"] += response.usage.output_tokens
        trace.append({"turn": turn + 1, "stop_reason": response.stop_reason})
        if response.stop_reason == "max_tokens":
            return {"status": "truncated", "trace": trace, "usage": usage}
        calls = [b for b in response.content if b.type == "tool_use"]
        if response.stop_reason == "tool_use":
            messages.append({"role": "assistant", "content": [
                b.model_dump(mode="json", exclude_none=True) for b in response.content]})
            results = []
            for call in calls:
                error = True
                if calls_used >= max_tools:
                    payload = {"error": "tool_budget_exhausted"}
                elif call.name != "retrieve_knowledge":
                    payload = {"error": "tool_not_allowed"}
                elif not isinstance(call.input, dict) or set(call.input) != {"query"} or not isinstance(call.input["query"], str) or not 1 <= len(call.input["query"].strip()) <= 300:
                    payload = {"error": "invalid_tool_arguments"}
                else:
                    calls_used += 1
                    result = await mcp_client.call_tool(call.name, call.input)
                    error = result.is_error
                    payload = result.structured_content if not error else {"error": "research_tool_failed"}
                    if not error:
                        evidence.update({d["id"]: d for d in payload["evidence"]})
                trace.append({"tool": call.name, "is_error": error})
                results.append({"type": "tool_result", "tool_use_id": call.id,
                                "content": json.dumps(payload), "is_error": error})
            messages.append({"role": "user", "content": results})
        elif response.stop_reason == "end_turn" and not calls:
            text = "\n".join(b.text for b in response.content if b.type == "text")
            final = validate_final(text, evidence)
            return {"status": "complete" if final["claims"] else "evidence_gap",
                    "protocol": mcp_client.protocol_version, "report": final,
                    "trace": trace, "usage": usage,
                    "validation_limit": "Citation IDs verified; claim entailment still needs review."}
        else:
            return {"status": "unexpected_stop", "trace": trace, "usage": usage}
    return {"status": "budget_exhausted", "trace": trace, "usage": usage}


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", required=True)
    args = parser.parse_args()
    if not 1 <= len(args.query.strip()) <= 4000:
        parser.error("Query must be 1–4000 characters")
    if not os.getenv("ANTHROPIC_API_KEY") or not os.getenv("ANTHROPIC_MODEL"):
        parser.error("Set ANTHROPIC_API_KEY and ANTHROPIC_MODEL; see README")
    from anthropic import Anthropic
    with Anthropic(max_retries=0, timeout=60) as model_client:
        async with Client(server_parameters(), read_timeout_seconds=10) as mcp_client:
            result = await run_mcp_agent(model_client, mcp_client, args.query, os.environ["ANTHROPIC_MODEL"])
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as exc:
        raise SystemExit("Run failed (" + type(exc).__name__ + "). Check API server, SDKs, model access, and environment.")
