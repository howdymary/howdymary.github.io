"""Shared read-only business capability. Neither HTTP nor MCP is the capability."""
import datetime as dt
import research_agent as core

SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "query": {"type": "string", "minLength": 1, "maxLength": 300},
        "as_of": {"type": "string", "format": "date", "default": "2026-11-16"},
        "top_k": {"type": "integer", "minimum": 1, "maximum": 5, "default": 3},
    }, "required": ["query"],
}


def research(payload):
    if not isinstance(payload, dict) or set(payload) - {"query", "as_of", "top_k"}:
        raise ValueError("Allowed fields: query, as_of, top_k. Identity cannot be supplied.")
    query = payload.get("query")
    if not isinstance(query, str) or not 1 <= len(query.strip()) <= 300:
        raise ValueError("query must be 1–300 characters")
    as_of, top_k = payload.get("as_of", "2026-11-16"), payload.get("top_k", 3)
    if not isinstance(as_of, str):
        raise ValueError("as_of must be an ISO date")
    dt.date.fromisoformat(as_of)
    if type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("top_k must be an integer from 1 to 5")
    docs = core.load_documents(core.ROOT / "sample_docs.json")
    # This service's bearer credential grants only the public-fixture read scope.
    # A real service must derive tenant/scopes from a trusted authenticated identity.
    evidence = core.retrieve(query.strip(), docs, principal="public", as_of=as_of,
                             max_age_days=45, top_k=top_k)
    report = core.compose(query.strip(), evidence)
    return {"query": query.strip(), "as_of": as_of,
            "status": "complete" if evidence else "evidence_gap",
            "evidence": evidence, **report}
