#!/usr/bin/env python3
"""Real MCP discovery and call over a subprocess; no model/paid API required."""
import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
from mcp import Client, StdioServerParameters

ROOT = Path(__file__).resolve().parent


def server_parameters():
    token = os.getenv("DEMO_API_TOKEN", "")
    if not token:
        raise ValueError("Set DEMO_API_TOKEN; also start api_server.py")
    # Pass only the child settings it needs. The API token never enters model args.
    return StdioServerParameters(command=sys.executable,
        args=[str(ROOT / "mcp_server.py")], cwd=str(ROOT),
        env={"DEMO_API_TOKEN": token,
             "DEMO_API_URL": os.getenv("DEMO_API_URL", "http://127.0.0.1:8771")})


async def inspect_and_call(query):
    async with Client(server_parameters(), read_timeout_seconds=10) as client:
        tools = await client.list_tools()
        resources = await client.list_resources()
        prompts = await client.list_prompts()
        policy = await client.read_resource("research://policy")
        prompt = await client.get_prompt("evidence_brief", {"question": query})
        result = await client.call_tool("retrieve_knowledge", {"query": query})
        return {"protocol_version": client.protocol_version,
                "server": client.server_info.name,
                "tools": [{"name": t.name, "input_schema": t.input_schema} for t in tools.tools],
                "resources": [str(r.uri) for r in resources.resources],
                "prompts": [p.name for p in prompts.prompts],
                "policy": [r.text for r in policy.contents if hasattr(r, "text")],
                "rendered_prompt": [m.content.text for m in prompt.messages if hasattr(m.content, "text")],
                "is_error": result.is_error,
                "tool_result": result.structured_content,
                "error_content": [b.text for b in result.content if hasattr(b, "text")] if result.is_error else []}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", default="Does SignalDesk support HubSpot?")
    args = parser.parse_args()
    print(json.dumps(asyncio.run(inspect_and_call(args.query)), indent=2))


if __name__ == "__main__":
    main()
