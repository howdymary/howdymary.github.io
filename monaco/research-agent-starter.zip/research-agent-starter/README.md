# Research agent starter — offline scaffold + optional live agent

`research_agent.py` uses **Python 3.9+ and only the standard library**.
That offline script makes **no network requests**, calls **no LLM**, and creates **no embeddings**.
The optional `live_agent.py` uses the official Anthropic SDK and makes paid API calls; see below. The new API/MCP lab adds real localhost transports without requiring a model or paid account.
It demonstrates lexical retrieval, dated evidence, permission filtering, cited
excerpts, evidence gaps, a step budget, and durable SQLite checkpoints. It is not
a production agent or a substitute for a semantic RAG implementation.

All SignalDesk product facts, prices, and `example.com` URLs are fictional fixtures.
The URLs illustrate provenance fields; they are not live supporting webpages.
The default research date is **2026-11-16** so the examples remain reproducible.

## Run

Unzip the download, open a terminal in this folder, then run:

```sh
python3 research_agent.py --query "Does SignalDesk support HubSpot?"
python3 research_agent.py --query "Does SignalDesk support Salesforce?"
python3 research_agent.py --query "What is the price?"
python3 research_agent.py --query "Does SignalDesk support Zapier?"
python3 eval_starter.py
```

Expected results:

| Query | Result |
| --- | --- |
| HubSpot | Supported integration, with its fixture citation |
| Salesforce | Planned and not currently available |
| Price, default date | USD 59/month, effective November 1 |
| Zapier | Explicit evidence gap; no invented answer |
| Enterprise onboarding | Evidence gap because the available note is stale |
| Project Cedar | Evidence gap for public identity; private fixture is excluded |

The JSON output includes `run_id`, `status`, `steps_used`, `findings`, `gaps`,
and source metadata. `claim` is a verbatim extracted fixture fact, not a model's
inference. `supported_by_fixture` describes its evidence status, not a confidence
percentage. An empty result does not prove a capability does not exist.

Inspect historical pricing:

```sh
python3 research_agent.py --query "What is the price?" --as-of 2026-10-20
```

The October fixture yields USD 49; November evidence is not used before its date.
`verified_at` controls freshness; `valid_from` and `valid_to` control effective
dates. Real sources often lack effective dates—do not invent them when ingesting.

## Follow the pipeline

1. `load_documents` validates fields and calculates text hashes.
2. `authorize_and_filter` filters documents by identity, date, and freshness.
3. `retrieve` applies transparent lexical matching to eligible documents only.
4. `compose` emits cited excerpts or an explicit evidence gap.
5. `run_pipeline` checkpoints progress and budgets into `runs.sqlite3`.

The lexical retriever requires every informative query token to appear in a
candidate. This deliberately conservative toy can miss relevant paraphrases and
multi-document answers. It uses a small stop-word list and pricing aliases. It is
not BM25, vector search, a reranker, or a language-understanding system.

## Budget and resume

The pipeline has two charged actions: retrieval and composition. A one-step
budget preserves retrieved evidence but returns no finished findings:

```sh
python3 research_agent.py --query "HubSpot" --max-steps 1
```

Copy the returned `run_id`, then:

```sh
python3 research_agent.py --resume-run YOUR_RUN_ID --max-steps 2
```

The second command loads the stored query and scope, rechecks current fixture
permissions, and composes without repeating completed retrieval. Other scope
flags do not change a resumed run. Completed runs require a fresh `--query`.
For isolated experiments, supply `--db /path/to/another.sqlite3`.

SQLite commits happen after completed actions. This is a teaching checkpoint,
not exactly-once execution: a crash during a tool call can leave an uncertain
outcome. External writes require provider idempotency keys or reconciliation.
The offline pipeline has no external writes. The evaluation uses temporary
databases and does not alter your normal run history.

## Adapter seams: turn the scaffold into your implementation

The code marks seams with `ADAPTER` comments:

- **Sources:** Replace the JSON loader with approved document or web ingestion.
  Preserve original text, dates, URL, entity, hash, permissions, and document IDs.
  Add parsing, chunk lineage, deletion handling, source snapshots, and refresh jobs.
- **Retrieval:** Replace lexical matching with keyword or hybrid retrieval and
  reranking. Evaluate it against the same questions. Keep authorization and
  freshness constraints upstream of any model context or result cache.
- **Synthesis:** Replace `compose` with a model call that returns structured
  claims and source IDs. Validate referenced IDs and check claim support. Preserve
  gaps and contradictions; a citation's existence alone does not prove support.
- **Research tools:** Add a read-only search/fetch tool only when fresh external
  research is needed. Bound calls, time, result size, retries, and spend. Treat
  fetched content as untrusted evidence, not instructions or authorization.
- **Agent loop:** Introduce model-chosen next steps only after the fixed baseline
  is useful. Validate each proposed tool and argument in trusted code. Persist
  progress and stop when the task is answered or its budget is exhausted.
- **Identity:** `--principal internal` only simulates a trusted identity for the
  fixture. Anyone with this local folder can read or change its files. Production
  identity must come from server-side authentication, with tenant isolation,
  current source ACLs, protected logs, retention rules, and revocation handling.

Do not put API keys in prompts or browser JavaScript. This scaffold requires none.
Keep outbound emails, publishing, and CRM changes outside the initial research
loop, with controls appropriate to the real user's authorization.

## Evaluate each next change

Run `python3 eval_starter.py`. It checks supported versus planned capabilities,
unknown facts, current versus historical prices, stale content, permissions,
budget/resume behavior, and permission revocation before resumed composition.
These checks validate this narrow fixture behavior, not production readiness.

For a real agent, add diverse held-out tasks, source contradictions, malformed
documents, tool failures, prompt injection, duplicate actions, and cost limits.
Track retrieval success, factual support, completeness, latency, spend, and human
review time separately. Roll out through offline tests, shadow runs, reviewed
drafts, and a limited pilot with a named owner and rollback path.


## Optional: run a real model + tool loop

`live_agent.py` is a working API adapter: Claude requests `retrieve_knowledge`,
Python executes the real retriever, then sends matching `tool_result` blocks back
through the Messages API. The model can query again or return a structured report.
Its evidence still comes from the fictional local fixtures. There is no web
research, vector search, email sending, publishing, or CRM mutation.

Use **Python 3.10+** for the current official SDK. From this folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install anthropic
export ANTHROPIC_API_KEY="YOUR_KEY_HERE"
export ANTHROPIC_MODEL="YOUR_SUPPORTED_MODEL_ID"
python3 live_agent.py --query "Does SignalDesk support HubSpot and Salesforce?"
```

`YOUR_KEY_HERE` is a placeholder, not a credential. Supply your key through your
preferred environment/secret manager; avoid saving a real key in shared files or
shell history. Both environment variables are required; the script selects no
model silently. `YOUR_SUPPORTED_MODEL_ID` is a placeholder. Choose an ID available to your account from the official model catalog and check current pricing before running. No model ID is selected silently.

Unlike the offline script, this sends the query and retrieved public fixture text
to Anthropic. API credits are required. Defaults limit the run to six API turns,
six executed tool calls, and 1,200 output tokens per API response. `--max-tokens`
is a per-response cap, not a dollar or total-input budget. Conversation history
adds input tokens on later calls. Output includes accumulated input/output usage;
apply your chosen model's rates to estimate cost. Automatic SDK retries are
explicitly disabled, and each request has a 60-second timeout.

The fixed `public` profile is enforced in dispatch code. The model cannot request
an internal identity, choose a source file, or alter access/freshness rules. Tool
arguments are validated and errors are returned using `is_error`. A truncated
response, invalid final JSON, or unknown source ID does not become a finished
report. Citation validation checks identity and schema only: a real source ID can
still be attached to a wrong claim. Add entailment evaluation and human review.

The live loop uses in-memory conversation state. It does not yet use the offline
script's SQLite resume feature. Its default fixture date is also 2026-11-16.
Before production, add durable execution, stronger retrieval, current sources,
proper identity, tracing/retention, and domain-specific quality evaluations.

### Verification and official references

```sh
python3 eval_starter.py
python3 eval_live_mock.py
```

Eight offline checks and four mock-loop checks passed. The mocks verify tool
result dispatch, fixed public permissions, invalid-citation rejection, and
budget/truncation handling. **The live API was not executed or verified with
credentials.** These checks do not establish live account access, model output
quality, or production readiness.

- [Official Python SDK and installation](https://github.com/anthropics/anthropic-sdk-python)
- [Client tool calls, tool_result formatting, and errors](https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls)
- [Current model IDs, capabilities, and pricing](https://platform.claude.com/docs/en/models/overview)


# API → MCP → model: the integration lab

## What you will actually run

```
api_client.py ── HTTP POST ──> api_server.py ──> research_service.py
                                                   │
                                                   └─> original fixture retriever

mcp_client.py ── MCP stdio ──> mcp_server.py ── same HTTP API ──> same service

live_mcp_agent.py ── optional model API ── tool request
        └─ host validation ── MCP client ── MCP server ── HTTP API ── evidence
```

The business capability is `research_service.research`. HTTP exposes that capability through a route and JSON schema. MCP exposes a model-friendly tool description and argument schema through a standard discovery/call interface. The model does not execute Python or HTTP by itself: the host validates its proposed call and invokes the adapter.

This lab uses the **official Python MCP SDK 2.3.0**, pinned in `requirements-mcp.txt`. It was executed with Python 3.14.6 on macOS. Use Python 3.11+ for these instructions. The actual stdio integration negotiated **MCP 2026-07-28**. Current SDK `Client` handles discovery/version negotiation on entry; do not add a hand-written legacy `initialize` handshake to this example. Protocol behavior and Python APIs are different versioned layers. Older SDK examples often use different classes and field names.

## 1. Install the one lab dependency

From the unzipped folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-mcp.txt
```

Windows activation is `.venv\Scripts\activate`. The HTTP service/direct client require only the standard library. The MCP examples require the pinned SDK. No credentials or paid model are needed for integration tests.

## 2. Start the real HTTP service

In terminal A:

```sh
export DEMO_API_TOKEN="local-learning-token"
python api_server.py
```

`local-learning-token` is a published, non-secret **local demonstration token**. Do not reuse it for a deployed service. The server binds **only 127.0.0.1:8771** and accepts no arbitrary upstream URLs. Leave this terminal running; stop with Ctrl+C.

In terminal B, activate the same virtual environment and set the same demo token:

```sh
source .venv/bin/activate
export DEMO_API_TOKEN="local-learning-token"
python api_client.py --query "Does SignalDesk support HubSpot?"
```

Expected: `status: complete`, a request ID, and a finding with source ID `signaldesk-hubspot-2026-11`. `Zapier` returns `evidence_gap`. A result with HTTP 200 can legitimately contain an evidence gap: transport success is different from a successful answer.

Inspect the raw HTTP boundary:

```sh
curl -i http://127.0.0.1:8771/v1/research \
  -H "Authorization: Bearer $DEMO_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"query":"HubSpot"}'

curl -s http://127.0.0.1:8771/v1/schema \
  -H "Authorization: Bearer $DEMO_API_TOKEN"
```

Request shape:

```json
{"query":"HubSpot","as_of":"2026-11-16","top_k":3}
```

Only `query` is required. `top_k` is an integer 1–5. `as_of` is a fixture date, not a live clock. `principal` and other extra fields are rejected. The bearer token authenticates access to this demo service; the service separately fixes the authorization scope to **public fixture evidence**. A real product must map verified identity to tenant/scopes in trusted code. This static token is not OAuth and does not demonstrate enterprise SSO.

Status semantics:

| Status | What happened | Appropriate response |
| --- | --- | --- |
| 200 | Request executed; inspect `status`/evidence | Use supported findings or report the gap |
| 400 | Invalid JSON/body schema | Fix the arguments; blind retry does not help |
| 401 | Missing/wrong bearer token | Fix authentication; do not treat as no evidence |
| 405 | Wrong HTTP method | Use POST for the query route |
| 413 | Body outside 1–8192 bytes | Reduce or fix the request |
| 415 | Unsupported content type | Send application/json |
| 429 | Demo quota exceeded | Read Retry-After; retry with a bounded policy |

Rate limiting is a deliberately small **single-process demonstration**, not distributed quota enforcement. Default is 30 authenticated requests per minute. Start with `--rate-limit 1` to reproduce 429 by making two calls. The direct client does not auto-retry, so errors remain visible. For read-only queries, bounded retries are possible; sending a message would also require provider idempotency or outcome reconciliation.

## 3. Discover and call the MCP server

Keep the API service running. In terminal B:

```sh
python mcp_client.py --query "Does SignalDesk support HubSpot?"
```

The client launches `mcp_server.py` as a child process, connects over **stdin/stdout**, lists tools, lists/reads a resource, lists/renders a prompt, and calls `retrieve_knowledge`. The MCP adapter then calls the SAME HTTP route from step 2.

Expected output includes:

- `protocol_version: 2026-07-28` for the pinned/tested SDK pairing.
- Tool `retrieve_knowledge`, with its JSON input schema.
- Resource `research://policy` containing fixed scope/freshness context.
- Prompt `evidence_brief`, a rendered reusable message template.
- `is_error: false` and a structured tool result containing the cited evidence.

The exact negotiated version is read from the connection, not hardcoded in the client. A tool is executable functionality. A resource supplies application-readable context. A prompt is a reusable message template; rendering it does not run a model or execute a tool.

There are **two separate connections**: stdio between MCP client/server, then HTTP between MCP server/API. `DEMO_API_TOKEN` is passed to the server process as an environment variable; it is not in the tool schema, model arguments, or returned evidence. The stdio channel relies on the local process boundary; it does not perform the remote MCP HTTP OAuth flow. Keep stdout for protocol messages and logs on stderr.

The returned `is_error` is distinct from an empty result. Check it before using `structured_content`. The SDK derives the tool's input schema from typed Python parameters and output schema from `ResearchResult`. Application validation still enforces business constraints and authorization.

## 4. Exercise all boundaries without a model

```sh
python eval_starter.py
python eval_live_mock.py
python eval_integrations.py
python eval_bridge.py
```

`eval_integrations.py` starts its own temporary API server on an available loopback port, generates an in-memory demo token, launches real MCP subprocesses, and cleans them up. It does not depend on your terminal-A service. The checks cover correct evidence, identity rejection, API401/schema errors/429, MCP discovery, resources/prompts, unknown tools, tool argument errors, authorization, and equality of the direct versus MCP findings.

`eval_bridge.py` uses a **mock model** but the **real MCP and HTTP transports**. It verifies that discovered schemas reach the model adapter, a tool-call ID is matched to the returned result, and the final answer's source IDs exist. It does not establish model reasoning quality.

## 5. Add the optional live model

Keep the API service running. Install the official model SDK and supply your own account settings:

```sh
python -m pip install -r requirements-live.txt
export ANTHROPIC_MODEL="YOUR_SUPPORTED_MODEL_ID"
# Set ANTHROPIC_API_KEY through your secret manager or private environment.
python live_mcp_agent.py --query "Does SignalDesk support HubSpot and Salesforce?"
```

This makes paid model API requests and sends the query plus retrieved public fixture text to Anthropic. It exposes only the host-allowlisted `retrieve_knowledge` tool. The host validates arguments, calls MCP, sends a matching `tool_result` back to the model, and validates the final report schema/source IDs. The defaults cap API turns and executed tools at six each, output at 1,200 tokens per response, API timeout at 60 seconds, and MCP wait at ten seconds. They are not a total-dollar budget. Model requests have automatic retries disabled. Conversation state is in memory; this live example does not promise crash-resume or exactly-once effects.

**No live model request was made during verification.** Actual model/account compatibility, quality, and cost remain to be evaluated with your selected model. Source-ID existence is not semantic entailment; review whether each passage actually supports its claim.

## Debugging exercises to perform yourself

1. Remove the demo token: predict API401 versus a model evidence gap, then inspect the failure.
2. Add `"principal":"internal"` to the HTTP JSON: observe schema rejection; explain why authorization never comes from model arguments.
3. Ask about `Project Cedar`: explain why a public caller receives no private evidence even though the fixture exists on disk.
4. Ask about October pricing and November pricing: inspect effective dates and explain why retrieval must preserve version context.
5. Stop terminal A: inspect the MCP tool error. Do not classify a network failure as proof that the feature does not exist.
6. Use an invalid tool name or numeric query through the MCP client: distinguish tool execution errors from valid empty results.
7. Run the bridge test, deliberately change its source ID, and confirm validation fails. Then explain why a real but irrelevant source ID still needs semantic evaluation.
8. Change the model's allowed tool set: demonstrate that discovering a tool does not automatically authorize exposing it.

## Explain the design aloud

“Direct API integration is enough when I own a small fixed set of service calls. I use MCP when I want hosts to discover a common tool interface with schemas and structured results. The MCP server can wrap an existing API; it does not replace the API's business logic or grant permissions. My harness still decides which tools to expose, validates arguments, manages budgets, tracks outcomes, and checks evidence. I would compare both designs on integration effort, reliability, latency, and reuse across customers.”

## Primary references and version notes

- [Official Python MCP SDK](https://github.com/modelcontextprotocol/python-sdk)
- [Official SDK client API](https://py.sdk.modelcontextprotocol.io/client/)
- [Running stdio and HTTP servers](https://py.sdk.modelcontextprotocol.io/run/)
- [MCP architecture](https://modelcontextprotocol.io/docs/learn/architecture)
- [MCP specification versions](https://modelcontextprotocol.io/specification)
- [Official Anthropic tool-call handling](https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls)

Current documentation was read during construction; the executable lab is pinned to SDK2.3.0 and reports its negotiated protocol. Current protocol concepts must not be silently illustrated as a legacy handshake. For production remote MCP, study the applicable authorization and transport specifications, then add TLS, identity/tenant mapping, least-privilege scopes, audit logging, limits, and deployment-specific hardening. This localhost teaching API intentionally does not claim to supply those production controls.


## Verification record

Verified November 16, 2026: 8 offline behavior checks, 4 mocked model-loop checks, 12 actual HTTP/MCP integration checks, and 1 mock-model/real-transport bridge check passed (25 total). All Python files parsed. SDK packages imported: MCP2.3.0 and Anthropic2.9.0. No live model, external web search, real customer data, or external write was exercised. Local integration tests start and stop their own processes; no service is left running.
