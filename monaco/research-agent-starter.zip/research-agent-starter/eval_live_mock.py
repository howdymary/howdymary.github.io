#!/usr/bin/env python3
"""Real loop logic with fake API responses: no key, SDK, or network required."""
import copy
import json
from types import SimpleNamespace
import live_agent as live
import research_agent as offline


class Block(SimpleNamespace):
    def model_dump(self, **kwargs):
        return vars(self).copy()


def response(reason, blocks):
    return SimpleNamespace(stop_reason=reason, content=blocks,
                           usage=SimpleNamespace(input_tokens=100, output_tokens=20))


def tool(query="HubSpot", **extra):
    return response("tool_use", [Block(type="tool_use", id="tool-1",
        name="retrieve_knowledge", input={"query": query, **extra})])


def final(source="signaldesk-hubspot-2026-11"):
    return response("end_turn", [Block(type="text", text=json.dumps({
        "claims": [{"text": "HubSpot is supported.", "source_ids": [source]}], "gaps": []}))])


class FakeClient:
    def __init__(self, responses):
        self.responses, self.requests, self.messages = iter(responses), [], self

    def create(self, **kwargs):
        self.requests.append(copy.deepcopy(kwargs))
        return next(self.responses)


def main():
    docs = offline.load_documents(offline.ROOT / "sample_docs.json")
    def run(client, **kwargs):
        return live.run_agent(client, "Does SignalDesk support HubSpot?", docs,
                              model="mock-only", **kwargs)
    client = FakeClient([tool(), final()])
    result = run(client)
    assert result["status"] == "complete" and result["tool_calls"] == 1
    history = client.requests[1]["messages"]
    assert history[-2]["role"] == "assistant"
    assert history[-1]["content"][0]["tool_use_id"] == "tool-1"
    print("PASS loop dispatches retrieval and returns matching tool_result")

    client = FakeClient([tool(principal="internal"), response("end_turn", [Block(
        type="text", text='{"claims":[],"gaps":["Tool arguments rejected."]}')])])
    assert run(client)["status"] == "evidence_gap"
    assert client.requests[1]["messages"][-1]["content"][0]["is_error"] is True
    assert live.dispatch("retrieve_knowledge", {"query": "Project Cedar"}, docs, "2026-11-16") == []
    print("PASS arguments cannot override fixed public permissions")

    result = run(FakeClient([tool(), final("invented-source")]))
    assert result["status"] == "validation_failed" and "report" not in result
    print("PASS unknown citation ID blocks final report")

    assert run(FakeClient([tool()]), max_turns=1)["status"] == "budget_exhausted"
    assert run(FakeClient([response("max_tokens", [])]))["status"] == "truncated"
    print("PASS turn budget and truncated output stop cleanly")
    print("All 4 mock checks passed. No live API was called.")


if __name__ == "__main__":
    main()
