#!/usr/bin/env python3
"""A real localhost HTTP API. Standard library; fictional evidence; read only."""
import argparse
import hmac
import json
import math
import os
import threading
import time
import uuid
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from research_service import SCHEMA, research


class ResearchHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, token, rate_limit=30):
        if address[0] != "127.0.0.1":
            raise ValueError("Teaching server must bind 127.0.0.1")
        if len(token) < 8:
            raise ValueError("Use a nonempty demo token of at least eight characters")
        self.token, self.rate_limit = token, rate_limit
        self.calls, self.lock = deque(), threading.Lock()
        super().__init__(address, Handler)

    def quota(self):
        with self.lock:
            now = time.monotonic()
            while self.calls and now - self.calls[0] >= 60:
                self.calls.popleft()
            if len(self.calls) >= self.rate_limit:
                return max(1, math.ceil(60 - (now - self.calls[0])))
            self.calls.append(now)
            return 0


class Handler(BaseHTTPRequestHandler):
    server_version = "ResearchLearningAPI/1.0"

    def log_message(self, *args):
        pass  # Keep credentials and request text out of example logs.

    def reply(self, status, data, headers=None):
        request_id = getattr(self, "request_id", uuid.uuid4().hex[:12])
        body = json.dumps({"request_id": request_id, **data}).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Request-ID", request_id)
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def authorized(self):
        self.request_id = uuid.uuid4().hex[:12]
        self.connection.settimeout(5)
        expected = "Bearer " + self.server.token
        if not hmac.compare_digest(self.headers.get("Authorization", "").encode(), expected.encode()):
            self.reply(401, {"error": "unauthorized"}, {"WWW-Authenticate": "Bearer"})
            return False
        return True

    def do_GET(self):
        if self.path == "/health":
            self.reply(200, {"status": "ready", "mode": "fictional_local_demo"})
            return
        if not self.authorized():
            return
        if self.path == "/v1/schema":
            self.reply(200, {"method": "POST", "path": "/v1/research", "input_schema": SCHEMA})
        elif self.path == "/v1/research":
            self.reply(405, {"error": "method_not_allowed"}, {"Allow": "POST"})
        else:
            self.reply(404, {"error": "not_found"})

    def do_POST(self):
        if not self.authorized():
            return
        if self.path != "/v1/research":
            self.reply(404, {"error": "not_found"})
            return
        if self.headers.get_content_type() != "application/json":
            self.reply(415, {"error": "content_type_must_be_application_json"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if not 0 < length <= 8192:
            self.reply(413, {"error": "body_size_must_be_1_to_8192_bytes"})
            return
        retry_after = self.server.quota()
        if retry_after:
            self.reply(429, {"error": "rate_limited"}, {"Retry-After": str(retry_after)})
            return
        try:
            payload = json.loads(self.rfile.read(length))
            self.reply(200, research(payload))
        except (ValueError, UnicodeDecodeError) as exc:
            self.reply(400, {"error": "invalid_request", "detail": str(exc)})
        except (TimeoutError, OSError):
            self.reply(408, {"error": "request_read_timeout"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8771)
    parser.add_argument("--rate-limit", type=int, default=30, help="Requests per minute; demo token scope")
    args = parser.parse_args()
    token = os.getenv("DEMO_API_TOKEN", "")
    if len(token) < 8 or not 1 <= args.port <= 65535 or not 1 <= args.rate_limit <= 1000:
        parser.error("Set DEMO_API_TOKEN (8+ characters), valid port, rate limit 1–1000")
    with ResearchHTTPServer(("127.0.0.1", args.port), token, args.rate_limit) as server:
        print(f"Read-only fictional API: http://127.0.0.1:{args.port}; Ctrl+C stops it.", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
