#!/usr/bin/env python3
"""Fake model, REAL MCP and HTTP. No paid API call or API credential."""
import asyncio
import json
import os
from types import SimpleNamespace
from mcp import Client
from mcp_client import server_parameters
from eval_integrations import api
from live_mcp_agent import run_mcp_agent


class Block(SimpleNamespace):
    def model_dump(self, **kwargs):
        return vars(self)


class FakeModel:
    def __init__(self):
        self.messages, self.turn = self, 0

    def create(self, **kwargs):
        self.turn += 1
        if self.turn == 1:
            assert kwargs["tools"][0]["input_schema"]["properties"]["query"]["type"] == "string"
            content = [Block(type="tool_use", id="example-tool-1", name="retrieve_knowledge", input={"query": "HubSpot"})]
            reason = "tool_use"
        else:
            tool_result = kwargs["messages"][-1]["content"][0]
            assert tool_result["tool_use_id"] == "example-tool-1" and not tool_result["is_error"]
            payload = json.loads(tool_result["content"])
            assert payload["evidence"][0]["id"] == "signaldesk-hubspot-2026-11"
            content = [Block(type="text", text=json.dumps({"claims": [{
                "text": "SignalDesk supports HubSpot.",
                "source_ids": ["signaldesk-hubspot-2026-11"]}], "gaps": []}))]
            reason = "end_turn"
        return SimpleNamespace(content=content, stop_reason=reason,
                               usage=SimpleNamespace(input_tokens=20, output_tokens=10))


async def main():
    with api() as (url, token):
        os.environ["DEMO_API_URL"], os.environ["DEMO_API_TOKEN"] = url, token
        async with Client(server_parameters(), read_timeout_seconds=10) as client:
            report = await run_mcp_agent(FakeModel(), client, "HubSpot", "mock-model")
            assert report["status"] == "complete"
            assert report["report"]["sources"][0]["id"] == "signaldesk-hubspot-2026-11"
    print("PASS model-shaped tool request → actual MCP → actual HTTP → matching tool_result → validated report")
    print("No live model API was called. Model output quality is not evaluated by this check.")


if __name__ == "__main__":
    asyncio.run(main())
