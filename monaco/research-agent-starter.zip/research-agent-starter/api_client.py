#!/usr/bin/env python3
"""Direct API adapter: transport, credentials, bounded wait, typed errors."""
import argparse
import json
import os
import urllib.error
import urllib.parse
import urllib.request


class APIError(Exception):
    def __init__(self, status, payload, retry_after=None):
        self.status, self.payload, self.retry_after = status, payload, retry_after
        super().__init__(f"HTTP {status}: {payload.get('error', 'request_failed')}")


def request_research(payload, *, base_url=None, token=None, timeout=3):
    base_url = base_url or os.getenv("DEMO_API_URL", "http://127.0.0.1:8771")
    parts = urllib.parse.urlsplit(base_url)
    if parts.scheme != "http" or parts.hostname != "127.0.0.1" or parts.username or parts.password or parts.path not in ("", "/") or parts.query or parts.fragment:
        raise ValueError("Demo API URL must be http://127.0.0.1:<port> with no extra path")
    token = token if token is not None else os.getenv("DEMO_API_TOKEN", "")
    if not token:
        raise ValueError("Set DEMO_API_TOKEN in the client environment")
    request = urllib.request.Request(base_url.rstrip("/") + "/v1/research",
        data=json.dumps(payload).encode(), method="POST",
        headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read(65537))
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read(8192))
        except (ValueError, UnicodeDecodeError):
            body = {"error": "non_json_error"}
        raise APIError(exc.code, body, exc.headers.get("Retry-After")) from exc
    # There are no automatic retries. A caller can retry reads after a bounded
    # backoff; a mutating tool would require an action ID and reconciliation.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(request_research({"query": args.query}), indent=2))
    except (APIError, ValueError, OSError, urllib.error.URLError) as exc:
        parser.exit(1, str(exc) + "\n")


if __name__ == "__main__":
    main()
