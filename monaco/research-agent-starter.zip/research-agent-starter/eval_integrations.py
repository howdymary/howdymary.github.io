#!/usr/bin/env python3
"""Exercises actual localhost HTTP and actual MCP stdio, without a live model."""
import asyncio
import contextlib
import json
import os
import secrets
import threading
import urllib.error
import urllib.request
from api_client import APIError, request_research
from api_server import ResearchHTTPServer
from mcp import Client
from mcp_client import server_parameters


@contextlib.contextmanager
def api(rate=100):
    token = secrets.token_urlsafe(24)
    server = ResearchHTTPServer(("127.0.0.1", 0), token, rate)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", token
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def expected_http(status, payload, url, token):
    try:
        request_research(payload, base_url=url, token=token)
    except APIError as exc:
        assert exc.status == status, (exc.status, exc.payload)
        return exc
    raise AssertionError(f"Expected HTTP {status}")


async def main():
    checks = []
    def passed(name):
        checks.append(name)
        print("PASS", name)

    with api() as (url, token):
        direct = request_research({"query": "HubSpot"}, base_url=url, token=token)
        assert direct["findings"][0]["source_id"] == "signaldesk-hubspot-2026-11"
        passed("HTTP success returns current cited evidence")
        expected_http(401, {"query": "HubSpot"}, url, "invalid-demo-token")
        passed("HTTP wrong bearer token is 401")
        expected_http(400, {"query": "Project Cedar", "principal": "internal"}, url, token)
        expected_http(400, {"query": 123}, url, token)
        expected_http(400, {"query": "HubSpot", "top_k": True}, url, token)
        passed("HTTP schema rejects bad types and caller-supplied identity")
        private = request_research({"query": "Project Cedar"}, base_url=url, token=token)
        assert private["status"] == "evidence_gap" and not private["evidence"]
        unknown = request_research({"query": "Zapier"}, base_url=url, token=token)
        assert unknown["status"] == "evidence_gap"
        passed("HTTP private and unknown evidence remain absent")
        current = request_research({"query": "price"}, base_url=url, token=token)
        old = request_research({"query": "price", "as_of": "2026-10-20"}, base_url=url, token=token)
        assert "59" in current["findings"][0]["claim"] and "49" in old["findings"][0]["claim"]
        passed("HTTP scope preserves current versus historical pricing")
        os.environ["DEMO_API_URL"], os.environ["DEMO_API_TOKEN"] = url, token
        async with Client(server_parameters(), read_timeout_seconds=10) as client:
            tools = await client.list_tools()
            assert [t.name for t in tools.tools] == ["retrieve_knowledge"]
            schema = tools.tools[0].input_schema
            assert "query" in schema["properties"] and "query" in schema["required"]
            version = client.protocol_version
            passed("MCP subprocess connects and discovers real tool schema")
            result = await client.call_tool("retrieve_knowledge", {"query": "HubSpot"})
            assert not result.is_error
            assert result.structured_content["findings"] == direct["findings"]
            passed("MCP tool invokes same HTTP capability and preserves evidence")
            resources = await client.list_resources()
            assert "research://policy" in [str(r.uri) for r in resources.resources]
            policy = await client.read_resource("research://policy")
            assert "public identity" in policy.contents[0].text
            prompts = await client.list_prompts()
            assert "evidence_brief" in [p.name for p in prompts.prompts]
            prompt = await client.get_prompt("evidence_brief", {"question": "HubSpot"})
            assert "HubSpot" in prompt.messages[0].content.text
            passed("MCP resources and prompts are discoverable and readable")
            invalid = await client.call_tool("retrieve_knowledge", {"query": 123})
            missing = await client.call_tool("nonexistent_tool", {})
            assert invalid.is_error and missing.is_error
            passed("MCP invalid arguments and unknown tool return error results")
            hidden = await client.call_tool("retrieve_knowledge", {"query": "Project Cedar"})
            assert not hidden.is_error and not hidden.structured_content["evidence"]
            passed("MCP cannot retrieve private fixtures through fixed API scope")
            # Distinguish API auth failures from empty retrieval.
        os.environ["DEMO_API_TOKEN"] = "wrong-demo-token"
        async with Client(server_parameters(), read_timeout_seconds=10) as client:
            result = await client.call_tool("retrieve_knowledge", {"query": "HubSpot"})
            assert result.is_error
            assert "401" in result.content[0].text
            passed("MCP propagates HTTP authentication failure as tool error")

    with api(rate=1) as (url, token):
        request_research({"query": "HubSpot"}, base_url=url, token=token)
        exc = expected_http(429, {"query": "HubSpot"}, url, token)
        assert int(exc.retry_after) > 0
        passed("HTTP rate limit returns 429 with Retry-After")

    print(json.dumps({"passed": len(checks), "mcp_sdk": "2.3.0",
                      "negotiated_protocol": version,
                      "transport": "actual stdio subprocess → localhost HTTP",
                      "live_model_called": False}, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
