#!/usr/bin/env python3
"""Small behavioral evaluation. No network or third-party dependencies."""
import copy
import json
import tempfile
from pathlib import Path
import research_agent as app


def main():
    docs = app.load_documents(app.ROOT / "sample_docs.json")
    with tempfile.TemporaryDirectory() as tmp:
        conn = app.open_db(Path(tmp) / "test.sqlite3")

        def ask(query, principal="public", as_of="2026-11-16", max_steps=2, corpus=None):
            state = app.new_state(query, principal, as_of, 45, max_steps)
            return app.run_pipeline(state, corpus or docs, conn), state

        report, _ = ask("Does SignalDesk support HubSpot?")
        assert report["status"] == "complete"
        assert report["findings"][0]["source_id"] == "signaldesk-hubspot-2026-11"
        assert report["findings"][0]["citation"]["fixture"] is True
        print("PASS supported capability has a valid fixture citation")

        report, _ = ask("Does SignalDesk support Salesforce?")
        assert "planned" in report["findings"][0]["claim"]
        assert "not currently available" in report["findings"][0]["claim"]
        print("PASS planned capability stays planned")

        for query in ("Does SignalDesk support Zapier?", "Does Salesforce support SSO?"):
            report, _ = ask(query)
            assert report["status"] == "evidence_gap" and not report["findings"]
        print("PASS unknown feature and unknown detail produce evidence gaps")

        report, _ = ask("What is the price?")
        assert len(report["findings"]) == 1
        assert "USD 59" in report["findings"][0]["claim"]
        report, _ = ask("What is the price?", as_of="2026-10-20")
        assert "USD 49" in report["findings"][0]["claim"]
        print("PASS effective dates choose 59 current and 49 historical")

        report, _ = ask("Enterprise onboarding")
        assert report["status"] == "evidence_gap"
        print("PASS stale evidence is excluded")

        report, _ = ask("Project Cedar")
        assert report["status"] == "evidence_gap"
        assert "private fixture" not in json.dumps(report)
        report, _ = ask("Project Cedar", principal="internal")
        assert report["status"] == "complete"
        print("PASS permission exclusion happens before retrieval")

        report, state = ask("HubSpot", max_steps=1)
        assert report["status"] == "budget_exhausted"
        assert state["completed"] == ["retrieve"]
        saved = conn.execute("SELECT state_json FROM runs WHERE run_id=?", (state["run_id"],)).fetchone()
        restored = json.loads(saved[0])
        restored["max_steps"] = 2
        report = app.run_pipeline(restored, docs, conn)
        assert report["status"] == "complete" and report["steps_used"] == 2
        print("PASS step budget, SQLite persistence, and checkpoint resume")

        _, state = ask("HubSpot", max_steps=1)
        revised = copy.deepcopy(docs)
        for doc in revised:
            if doc["id"] == "signaldesk-hubspot-2026-11":
                doc["allowed_principals"] = ["internal"]
        state["max_steps"] = 2
        report = app.run_pipeline(state, revised, conn)
        assert report["status"] == "evidence_gap"
        print("PASS revoked permission rechecked before resumed composition")
        conn.close()
    print("All 8 behavioral checks passed.")


if __name__ == "__main__":
    main()
